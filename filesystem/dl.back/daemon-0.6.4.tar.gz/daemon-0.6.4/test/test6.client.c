#include <stdio.h>

int main(int ac, char **av)
{
	printf("test6\n");
	return 0;
}
